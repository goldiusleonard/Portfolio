<?php $__env->startSection('title', __('Log Out')); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/logout.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="container">
        <img class="logout-icon" src="<?php echo e(URL::asset('images/check_icon.png')); ?>" alt="">
        <h2 class="logout-text"><?php echo e(__('Log Out Success')); ?></h2>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\UAS\amazing_ebook\resources\views/logout.blade.php ENDPATH**/ ?>