<?php $__env->startSection('title', __('Update Role')); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/updaterole.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="sub-menu">
        <div class="sub-menu-bar">
            <a class="menu-choice" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
            <a class="menu-choice" href="<?php echo e(route('cart')); ?>"><?php echo e(__('Cart')); ?></a>
            <a class="menu-choice" href="<?php echo e(route('profile')); ?>"><?php echo e(__('Profile')); ?></a>
            <a class="menu-choice selected" href="<?php echo e(route('account_maintenance')); ?>"><?php echo e(__('Account Maintenance')); ?></a>
        </div>
    </div>

    <div class="container">
        <form class="update-form" method="post" action="/update_role/<?php echo e($targetUser->id); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-row">
                <label class="update-label" for=""><?php echo e(__('Name')); ?>:</label>
                <?php if(empty($targetUser->middle_name)): ?>
                    <p class="user-name"><?php echo e($targetUser->first_name . " " . $targetUser->last_name); ?></p>
                <?php else: ?>
                    <p class="user-name"><?php echo e($targetUser->first_name . " " . $targetUser->middle_name . " " . $targetUser->last_name); ?></p>
                <?php endif; ?>
            </div>

            <div class="form-row">
                <label class="update-label" for="role"><?php echo e(__('Role')); ?>:</label>
                <select class="role-select" name="role" id="role">
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($role->id == $targetUser->role->id): ?>
                            <option selected value="<?php echo e($role->id); ?>"><?php echo e($role->role_desc); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($role->id); ?>"><?php echo e($role->role_desc); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <input class="save-btn" type="submit" value="<?php echo e(__('Save')); ?>">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\UAS\amazing_ebook\resources\views/updaterole.blade.php ENDPATH**/ ?>