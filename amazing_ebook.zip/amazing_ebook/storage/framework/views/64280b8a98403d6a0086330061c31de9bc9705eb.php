<?php $__env->startSection('title', $ebook->title); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/ebookdetail.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="sub-menu">
        <div class="sub-menu-bar">
            <?php if($user->role->role_desc == 'User'): ?>
                <a class="menu-choice selected" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                <a class="menu-choice" href="<?php echo e(route('cart')); ?>"><?php echo e(__('Cart')); ?></a>
                <a class="menu-choice" href="<?php echo e(route('profile')); ?>"><?php echo e(__('Profile')); ?></a>
            <?php elseif($user->role->role_desc == 'Admin'): ?>
                <a class="menu-choice selected" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                <a class="menu-choice" href="<?php echo e(route('cart')); ?>"><?php echo e(__('Cart')); ?></a>
                <a class="menu-choice" href="<?php echo e(route('profile')); ?>"><?php echo e(__('Profile')); ?></a>
                <a class="menu-choice" href="<?php echo e(route('account_maintenance')); ?>"><?php echo e(__('Account Maintenance')); ?></a>
            <?php endif; ?>
        </div>
    </div>

    <div class="container">
        <img class="ebook-detail-picture" src="<?php echo e(URL::asset('images/book_picture2.png')); ?>" alt="">
        <div class="ebook-detail">
            <h2 class="ebook-title"><?php echo e($ebook->title); ?></h2>
            <h3 class="ebook-author"><?php echo e(__('BY')); ?>: <?php echo e($ebook->author); ?></h3>
            <p class="ebook-description"><u><?php echo e(__('Description')); ?>:</u><br><br><?php echo e($ebook->description); ?></p>
        </div>
    </div>
    <form class="rent-form" method="post" action="/ebook_detail/<?php echo e($ebook->id); ?>">
        <?php echo csrf_field(); ?>
        <input class="rent-btn" type="submit" value="<?php echo e(__('Rent')); ?>">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\UAS\amazing_ebook\resources\views/ebookdetail.blade.php ENDPATH**/ ?>