<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="<?php echo e(URL::asset('images/binusLogo.png')); ?>" type="image/x-icon">
    <title><?php echo $__env->yieldContent('title'); ?> | Binus Forum</title>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/layout.css')); ?>">
</head>
<body>
    <div class="navbar">
        <div class="menu-section logo-section">
            <a href="<?php echo e(route('home')); ?>" class="nav-logo">
                <img src="<?php echo e(URL::asset('images/binusLogo.png')); ?>" alt="" class="logo-img">
            </a>
        </div>

        <?php if(auth()->guard()->guest()): ?>
            <div class="menu-section profile-section">
                <a href="<?php echo e(route('login')); ?>" class="nav-menu dropdown">
                    <p>LOGIN</p>
                </a>
                <a href="<?php echo e(route('register')); ?>" class="nav-menu dropdown">
                    <p>REGISTER</p>
                </a>
            </div>
        <?php endif; ?>

        <?php if(auth()->guard()->check()): ?>
            <div class="menu-section nav-section">
                <a href="<?php echo e(route('home')); ?>" class="nav-menu">
                    <p>Home</p>
                </a>
                <div class="dropdown">
                    <div class="dropdown-button">
                        <p>Courses</p>
                        <img src="<?php echo e(URL::asset('images/dropdown-arrow.png')); ?>" alt="" class="dropdown-arrow">
                    </div>

                    <div class="dropdown-content">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-choice" href="/course/<?php echo e($course->id); ?>"><?php echo e($course->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class="menu-section profile-section">
                <div class="dropdown">
                    <div class="dropdown-button">
                        <p><?php echo e(Auth::user()->username); ?></p>
                        <img src="<?php echo e(URL::asset('images/dropdown-arrow.png')); ?>" alt="" class="dropdown-arrow">
                    </div>
                    <div class="dropdown-content">
                        <a class="dropdown-choice" href="<?php echo e(route('create_post')); ?>">Create Post</a>
                        <a class="dropdown-choice" href="<?php echo e(route('bookmark')); ?>">My Bookmark</a>
                        <a class="dropdown-choice logout" href="<?php echo e(route('logout_process')); ?>">Logout</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="content">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <footer>
        <div class="footer-row">
            <img class="location-icon" src="<?php echo e(URL::asset('images/location.png')); ?>" alt="">
            <h3 class="location">Jl. Raya Kb. Jeruk No.27</h3>
        </div>
        <div class="footer-row">
            <h3 class="copyright">&copy Binus Forum 2022</h3>
        </div>
    </footer>
</body>
</html>
<?php /**PATH C:\Users\chris\Downloads\binus_forum\binus_forum\resources\views/master/layout.blade.php ENDPATH**/ ?>