<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="<?php echo e(URL::asset('images/logo.png')); ?>" type="image/x-icon">
    <title><?php echo $__env->yieldContent('title'); ?> | Amazing E-Book</title>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/layout.css')); ?>">
</head>
<body>
    <nav>
        <div class="logo-section">
            <a class="logo-btn" href="<?php echo e(route('home')); ?>">
                <img class="logo-icon" src="<?php echo e(URL::asset('images/logo.png')); ?>" alt="">
                <h3 class="logo-title">Amazing E-Book</h3>
            </a>
        </div>

        <div class="login-section">
            <?php if(auth()->guard()->guest()): ?>
                <a class="sign-up-btn" href="<?php echo e(route('signup')); ?>">
                    <h3 class="sign-up-text"><?php echo e(__('Sign Up')); ?></h3>
                </a>

                <a class="log-in-btn" href="<?php echo e(route('login')); ?>">
                    <h3 class="log-in-text"><?php echo e(__('Log In')); ?></h3>
                </a>

                <div class="lang-dropdown">
                    <div class="lang-btn">
                        <h3 class="lang-text"><?php echo e(Config::get('languages')[App::getLocale()]); ?></h3>
                        <img class="dropdown-arrow" src="<?php echo e(URL::asset('images/dropdown_arrow.png')); ?>" alt="">
                    </div>

                    <div class="lang-dropdown-content">
                        <?php $__currentLoopData = Config::get('languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($lang != App::getLocale()): ?>
                                <a class="dropdown-item" href="<?php echo e(route('lang.switch', $lang)); ?>"> <?php echo e($language); ?></a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
                <a class="log-out-btn" href="<?php echo e(route('logout_process')); ?>">
                    <h3 class="log-out-text"><?php echo e(__('Log Out')); ?></h3>
                </a>

                <div class="lang-dropdown">
                    <div class="lang-btn">
                        <h3 class="lang-text"><?php echo e(Config::get('languages')[App::getLocale()]); ?></h3>
                        <img class="dropdown-arrow" src="<?php echo e(URL::asset('images/dropdown_arrow.png')); ?>" alt="">
                    </div>

                    <div class="lang-dropdown-content">
                        <?php $__currentLoopData = Config::get('languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($lang != App::getLocale()): ?>
                                <a class="dropdown-item" href="<?php echo e(route('lang.switch', $lang)); ?>"> <?php echo e($language); ?></a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <img class="photo-profile-img" src="<?php echo e(asset('storage/' . $user->display_picture_link)); ?>" alt="">
            <?php endif; ?>
        </div>
    </nav>

    <div class="content-wrapper">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <footer>
        <p class="footer-copyright">&copy <?php echo e(__('Footer')); ?></p>
    </footer>

</body>
</html>
<?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\UAS\amazing_ebook\resources\views/master/layout.blade.php ENDPATH**/ ?>