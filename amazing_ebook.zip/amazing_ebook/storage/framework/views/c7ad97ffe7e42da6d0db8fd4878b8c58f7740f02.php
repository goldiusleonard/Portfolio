<?php $__env->startSection('title', 'Profile Saved'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/saveprofile.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="container">
        <img class="checkout-icon" src="<?php echo e(URL::asset('images/check_icon.png')); ?>" alt="">
        <h2 class="checkout-text">Profile Saved</h2>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\UAS\amazing_ebook\resources\views/saveproifile.blade.php ENDPATH**/ ?>