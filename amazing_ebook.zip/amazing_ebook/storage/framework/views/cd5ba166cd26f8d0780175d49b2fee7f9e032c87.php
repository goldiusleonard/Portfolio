<?php $__env->startSection('title', __('Cart')); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/cart.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="sub-menu">
        <div class="sub-menu-bar">
            <?php if($user->role->role_desc == 'User'): ?>
                <a class="menu-choice" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                <a class="menu-choice selected" href="<?php echo e(route('cart')); ?>"><?php echo e(__('Cart')); ?></a>
                <a class="menu-choice" href="<?php echo e(route('profile')); ?>"><?php echo e(__('Profile')); ?></a>
            <?php elseif($user->role->role_desc == 'Admin'): ?>
                <a class="menu-choice" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                <a class="menu-choice selected" href="<?php echo e(route('cart')); ?>"><?php echo e(__('Cart')); ?></a>
                <a class="menu-choice" href="<?php echo e(route('profile')); ?>"><?php echo e(__('Profile')); ?></a>
                <a class="menu-choice" href="<?php echo e(route('account_maintenance')); ?>"><?php echo e(__('Account Maintenance')); ?></a>
            <?php endif; ?>
        </div>
    </div>

    <div class="container">
        <div class="order-section">
            <h2 class="order-section-title"><?php echo e(__('My Cart')); ?></h2>

            <?php if($orders->isEmpty()): ?>
                <div class="order-list">
                    <img class="order-list-empty-icon" src="<?php echo e(URL::asset('images/empty_icon.png')); ?>" alt="">
                    <h3 class="order-list-empty"><?php echo e(__('order list empty')); ?></h3>
                </div>
            <?php else: ?>
                <div class="order-list">
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="order-item" href="/ebook_detail/<?php echo e($order->ebook->id); ?>">
                            <form method="post" action="/delete_order/<?php echo e($order->id); ?>" class="order-form">
                                <?php echo csrf_field(); ?>
                                <div class="order-detail">
                                    <h3 class="order-title"><?php echo e($order->ebook->title); ?></h3>
                                    <h5 class="order-author"><?php echo e(__('Author')); ?>: <?php echo e($order->ebook->author); ?></h5>
                                </div>
                                <button class="delete-btn" type="submit" value="Delete">
                                    <img class="delete-img" src="<?php echo e(URL::asset('images/delete_btn.png')); ?>" alt="">
                                </button>
                            </form>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <?php if($orders->lastPage() > 1): ?>
                <div class="pagination">
                    <?php if($orders->currentPage() > 1): ?>
                        <a class="pagination-btn" href="<?php echo e($orders->url($orders->currentPage() - 1)); ?>"><?php echo e(__('Previous')); ?></a>
                    <?php endif; ?>

                    <p class="pagination-page"><?php echo e($orders->firstItem()); ?> - <?php echo e($orders->lastItem()); ?> <?php echo e(__('of')); ?> <?php echo e($orders->total()); ?></p>

                    <?php if($orders->currentPage() != $orders->lastPage()): ?>
                        <a class="pagination-btn" href="<?php echo e($orders->url($orders->currentPage() + 1)); ?>"><?php echo e(__('Next')); ?></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php if($orders->total() > 0): ?>
        <form class="checkout-form" method="post" action="/cart">
            <?php echo csrf_field(); ?>
            <input class="checkout-btn" type="submit" value="<?php echo e(__('Checkout')); ?>">
        </form>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\UAS\amazing_ebook\resources\views/cart.blade.php ENDPATH**/ ?>