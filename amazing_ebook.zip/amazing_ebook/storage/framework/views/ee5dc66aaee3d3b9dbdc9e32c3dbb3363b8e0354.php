<?php $__env->startSection('title', 'Manage Courses'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/manageCourses.css')); ?>">

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\Project Kelas\binus_forum (Mario)\resources\views/manageCourses.blade.php ENDPATH**/ ?>