<?php $__env->startSection('title', __('Account Maintenance')); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/accountmaintenance.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="sub-menu">
        <div class="sub-menu-bar">
            <a class="menu-choice" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
            <a class="menu-choice" href="<?php echo e(route('cart')); ?>"><?php echo e(__('Cart')); ?></a>
            <a class="menu-choice" href="<?php echo e(route('profile')); ?>"><?php echo e(__('Profile')); ?></a>
            <a class="menu-choice selected" href="<?php echo e(route('account_maintenance')); ?>"><?php echo e(__('Account Maintenance')); ?></a>
        </div>
    </div>

    <div class="container">
        <div class="account-section">
            <h2 class="account-section-title"><?php echo e(__('Account Maintenance')); ?></h2>

            <?php if($accounts->isEmpty()): ?>
                <div class="account-list">
                    <img class="account-list-empty-icon" src="<?php echo e(URL::asset('images/empty_icon.png')); ?>" alt="">
                    <h3 class="account-list-empty"><?php echo e(__('account list empty')); ?></h3>
                </div>
            <?php else: ?>
                <div class="account-list">
                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($account->delete_flag == false): ?>
                            <form method="post" action="/delete_user/<?php echo e($account->id); ?>" class="account-form">
                                <?php echo csrf_field(); ?>
                                <div class="account-detail">
                                    <?php if(empty($account->middle_name)): ?>
                                        <h3 class="account-name"><?php echo e($account->first_name . " " . $account->last_name); ?></h3>
                                    <?php else: ?>
                                        <h3 class="account-name"><?php echo e($account->first_name . " " . $account->middle_name . " " . $account->last_name); ?></h3>
                                    <?php endif; ?>
                                    <h5 class="account-role"><?php echo e(__('Role')); ?>: <?php echo e($account->role->role_desc); ?></h5>
                                </div>

                                <a class="update-btn" href="/update_role/<?php echo e($account->id); ?>">
                                    <img class="update-img" src="<?php echo e(URL::asset('images/update_btn.png')); ?>" alt="">
                                </a>

                                <button class="delete-btn" type="submit" value="Delete">
                                    <?php echo e(__('Deactivate')); ?>

                                </button>
                            </form>
                        <?php else: ?>
                            <form method="post" action="/recover_user/<?php echo e($account->id); ?>" class="account-form">
                                <?php echo csrf_field(); ?>
                                <div class="account-detail">
                                    <?php if(empty($account->middle_name)): ?>
                                        <h3 class="account-name"><?php echo e($account->first_name . " " . $account->last_name); ?></h3>
                                    <?php else: ?>
                                        <h3 class="account-name"><?php echo e($account->first_name . " " . $account->middle_name . " " . $account->last_name); ?></h3>
                                    <?php endif; ?>
                                    <h5 class="account-role"><?php echo e(__('Role')); ?>: <?php echo e($account->role->role_desc); ?></h5>
                                </div>

                                <a class="update-btn" href="/update_role/<?php echo e($account->id); ?>">
                                    <img class="update-img" src="<?php echo e(URL::asset('images/update_btn.png')); ?>" alt="">
                                </a>

                                <button class="reactivate-btn" type="submit" value="Delete">
                                    <?php echo e(__('Reactivate')); ?>

                                </button>
                            </form>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <?php if($accounts->lastPage() > 1): ?>
                <div class="pagination">
                    <?php if($accounts->currentPage() > 1): ?>
                        <a class="pagination-btn" href="<?php echo e($accounts->url($accounts->currentPage() - 1)); ?>"><?php echo e(__('Previous')); ?></a>
                    <?php endif; ?>

                    <p class="pagination-page"><?php echo e($accounts->firstItem()); ?> - <?php echo e($accounts->lastItem()); ?> <?php echo e(__('of')); ?> <?php echo e($accounts->total()); ?></p>

                    <?php if($accounts->currentPage() != $accounts->lastPage()): ?>
                        <a class="pagination-btn" href="<?php echo e($accounts->url($accounts->currentPage() + 1)); ?>"><?php echo e(__('Next')); ?></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\UAS\amazing_ebook\resources\views/accountmaintenance.blade.php ENDPATH**/ ?>