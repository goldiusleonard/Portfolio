<?php $__env->startSection('title', __('Profile Saved')); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/saveprofile.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="sub-menu">
        <div class="sub-menu-bar">
            <?php if($user->role->role_desc == 'User'): ?>
                <a class="menu-choice" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                <a class="menu-choice" href="<?php echo e(route('cart')); ?>"><?php echo e(__('Cart')); ?></a>
                <a class="menu-choice selected" href="<?php echo e(route('profile')); ?>"><?php echo e(__('Profile')); ?></a>
            <?php elseif($user->role->role_desc == 'Admin'): ?>
                <a class="menu-choice" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                <a class="menu-choice" href="<?php echo e(route('cart')); ?>"><?php echo e(__('Cart')); ?></a>
                <a class="menu-choice selected" href="<?php echo e(route('profile')); ?>"><?php echo e(__('Profile')); ?></a>
                <a class="menu-choice" href="<?php echo e(route('account_maintenance')); ?>"><?php echo e(__('Account Maintenance')); ?></a>
            <?php endif; ?>
        </div>
    </div>

    <div class="container">
        <img class="checkout-icon" src="<?php echo e(URL::asset('images/check_icon.png')); ?>" alt="">
        <h2 class="checkout-text"><?php echo e(__('Profile Saved')); ?></h2>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\UAS\amazing_ebook\resources\views/saveprofile.blade.php ENDPATH**/ ?>