<?php $__env->startSection('title', 'Bookmark Post'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/bookmark.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="bookmark-section">
        <h2 class="section-title">YOUR BOOKMARK</h2>
        <h3 class="section-subtitle">Save your favourite post here</h3>
    </div>

    <div class="search-section">
        <form method="get" action="">
            <input class="textbox" type="text" name="" id="" placeholder="Topic">
            <input class="search-button" type="submit" value="Search">
        </form>
    </div>

    <div class="list-section">
        <?php if($bookmarkPosts->isEmpty()): ?>
            <div class="empty-list">
                <h3 class="empty-text">No Post Yet ..</h3>
            </div>
        <?php else: ?>
            <?php $__currentLoopData = $bookmarkPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/post/<?php echo e($post->posts_id); ?>" class="bookmark-post">
                    <div class="post-detail">
                        <h3 class="post-title"><?php echo e($post->posts->title); ?></h3>
                        <h4 class="post-profile-name">Posted by: <?php echo e($post->users->name); ?></h4>
                    </div>

                    <div class="post-profile">
                        <p class="like-number"><?php echo e($post->posts->likes); ?></p>
                        <img class="like-icon" src="<?php echo e(URL::asset('images/like_button.png')); ?>" alt="">
                        <p class="dislike-number"><?php echo e($post->posts->dislikes); ?></p>
                        <img class="dislike-icon" src="<?php echo e(URL::asset('images/dislike_button.png')); ?>" alt="">
                        <form class="delete-form" action="/delete_bookmark/<?php echo e($post->id); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="delete-button" type="submit"></button>
                        </form>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FileCko\Kuliah\binus_forum\resources\views/bookmarkpost.blade.php ENDPATH**/ ?>