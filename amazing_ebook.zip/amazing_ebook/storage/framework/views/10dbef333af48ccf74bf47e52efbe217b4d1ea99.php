<?php $__env->startSection('title', 'Manage Courses'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/manageCourses.css')); ?>">

<?php $__env->startSection('content'); ?>

    <div class="container-title">
        <div class="blank-div"></div> 
        <div>Manage Courses</div>
        <div class="add-course">
            <a href="/create_course">
                New Course
                <img class="icon" src="<?php echo e(URL::asset('images/plus.png')); ?>" alt="">
            </a>
        </div>
    </div>

    <div class="container-box">
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="course-item">
                <div class="course-name">
                    <?php echo e($course->name); ?>

                </div>
                <div class="course-options">
                    <div >
                        <a href="/edit_course/<?php echo e($course->id); ?>" class="edit-course">
                            Edit Course
                            <img class="icon" src="<?php echo e(URL::asset('images/edit_icon.png')); ?>" alt="">
                        </a>
                    </div>
                    <div >
                        <a href="/delete_course/<?php echo e($course->id); ?>" class="delete-course">
                            Delete Course
                            <img class="icon" src="<?php echo e(URL::asset('images/trash.png')); ?>" alt="">
                        </a>
                    </div>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BINUS UNIVERSITY\Semester 5\Web Programming\Project Dosen\binus_forum\resources\views/manageCourses.blade.php ENDPATH**/ ?>