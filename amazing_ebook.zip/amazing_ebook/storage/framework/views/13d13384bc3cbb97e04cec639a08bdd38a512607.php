<?php $__env->startSection('title', 'Create Post'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/createpost.css')); ?>">
    <br><br><br><br>


<?php if(Session::has('success')): ?>
<div class="success">
  <h4>
    <?php echo e(Session::get('success')); ?>

  </h4>

    <?php
        Session::forget('success');
    ?>
</div>
<?php endif; ?>



<?php if($errors->any()): ?>
<div class="error">
    <p><strong>Opps Something went wrong</strong></p>
    <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>


<div class="container">
    <form class="form"action="/send_post/<?php echo e($user->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <strong>Courses</strong>
        <br>
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="radio" required name="courses_id" id="courses_id" value="<?php echo e($course->id); ?>">
            <?php echo e($course->name); ?>

            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br>
        <label for="title">Title</label>
        <br>
        <input class="input" type="text" name="title" id="title" required>
        <br>
        <label for="description"> Write here</label>
        <br>
        <textarea  class="input" name="description" id="description" cols="50" rows="5" required minlength="5">
        </textarea>
        <br>
        <br>
        <button class="submit-button" type="submit" >Create Post</button>
    </form>

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\Project Kelas\binus_forum (Mario)\resources\views/createPost.blade.php ENDPATH**/ ?>