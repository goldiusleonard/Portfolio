<?php $__env->startSection('title', 'Reply'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/reply.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="divider">
        <div class="left-section">
            <div class="left-profile">
                <img class="post-profile-picture" src="<?php echo e(URL::asset('images/profile_picture.png')); ?>" alt="">
                <h3 class="posted-by">Posted By</h3>
                <hr class="profile-line">
                <h3 class="post-profile-name"><?php echo e($currentPost->users->name); ?></h3>
                <h4 class="post-profile-role"><?php echo e($currentPost->users->roles->name); ?></h4>
            </div>
        </div>
        <div class="right-section">
            <div class="question-subsection">
                <h1 class="question-title"><?php echo e($currentPost->title); ?></h1>
                <h3 class="question-date"><?php echo e($currentPost->created_at); ?></h3>
                <p class="question-description"><?php echo e($currentPost->description); ?></p>

                <div class="question-action">
                    <p class="like-number"><?php echo e($currentPost->likes); ?></p>
                    <a class="like-button" href="/like_post/<?php echo e($currentPost->id); ?>">
                        <img class="like-icon" src="<?php echo e(URL::asset('images/like_button.png')); ?>" alt="">
                    </a>
                    <p class="dislike-number"><?php echo e($currentPost->dislikes); ?></p>
                    <a class="dislike-button" href="/dislike_post/<?php echo e($currentPost->id); ?>">
                        <img class="dislike-icon" src="<?php echo e(URL::asset('images/dislike_button.png')); ?>" alt="">
                    </a>
                    <a class="bookmark-button" href="/bookmark_process/<?php echo e($currentPost->id); ?>">
                        <?php if($bookmark): ?>
                        <img class="bookmark-icon" src="<?php echo e(URL::asset('images/bookmarked_icon.png')); ?>" alt="">
                        <?php else: ?>
                        <img class="bookmark-icon" src="<?php echo e(URL::asset('images/bookmark_icon.png')); ?>" alt="">
                        <?php endif; ?>
                    </a>
                </div>
            </div>

            <h2 class="reply-section-title">Replies</h2>

            <div class="reply-subsection">
                <form class="reply-form" method="post" action="/reply/<?php echo e($currentPost->id); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="text" class="title-textbox" placeholder="Title" name="title" id="title" <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="errorAlert"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <textarea class="description-textarea" name="description" id="description"
                        placeholder="add your message here"></textarea>

                    <div class="question-action">
                        <input class="submit-button" type="submit" value="reply">
                    </div>
                </form>
            </div>

            <?php if($currentReplies->isEmpty()): ?>
                <div class="reply-subsection">
                    <h3 class="empty-text">Be the first to reply!</h3>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $currentReplies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="reply-subsection">
                        <div class="reply-profile">
                            <img class="reply-photo" src="<?php echo e(URL::asset('images/profile_picture.png')); ?>" alt="">
                            <div class="reply-profile-detail">
                                <p class="reply-name"><?php echo e($reply->users->name); ?></p>
                                <p class="reply-role"><?php echo e($reply->users->roles->name); ?></p>
                            </div>
                        </div>

                        <hr>

                        <h1 class="reply-title"><?php echo e($reply->title); ?></h1>
                        <h3 class="reply-date"><?php echo e($reply->created_at); ?></h3>
                        <p class="reply-description"><?php echo e($reply->description); ?></p>

                        <div class="question-action">
                            <p class="like-number"><?php echo e($reply->likes); ?></p>
                            <a class="like-button" href="/like_reply/<?php echo e($reply->id); ?>">
                                <img class="like-icon" src="<?php echo e(URL::asset('images/like_button.png')); ?>" alt="">
                            </a>
                            <p class="dislike-number"><?php echo e($reply->dislikes); ?></p>
                            <a class="dislike-button" href="/dislike_reply/<?php echo e($reply->id); ?>">
                                <img class="dislike-icon" src="<?php echo e(URL::asset('images/dislike_button.png')); ?>" alt="">
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\Project Kelas\binus_forum\resources\views/reply.blade.php ENDPATH**/ ?>