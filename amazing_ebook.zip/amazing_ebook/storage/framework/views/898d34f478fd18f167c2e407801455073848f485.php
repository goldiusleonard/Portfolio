<?php $__env->startSection('title', 'category'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/forum.css')); ?>">

<?php $__env->startSection('content'); ?>
    

    <div class="content">
        <div class="feature_section">
            <h2 class="feature-title"><?php echo e($selected_course->name); ?> Forum</h2>
        </div>
        <div class="feature_list">
            <div class="menu-section nav-section">

            </div>
        </div>

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <div class="post_left">
                    <div>
                        <div class="user_role">
                            <?php echo e($post->users->roles->name); ?>

                        </div>
                        <div class="user_name">
                            <?php echo e($post->users->name); ?>

                        </div>
                    </div>
                    <h3><?php echo e($post->title); ?></h3>
                </div>
                <div class="post_right">
                    <div class="likes_count">
                        <?php echo e($post->likes); ?>

                        <button class="like_btn">
                            <span id="icon"><i class="far fa-thumbs-up"></i></span>
                            <span id="count">0</span> Like
                        </button>
                        <!-- like logo -->
                    </div>
                    <div class="dislikes_count">
                        <?php echo e($post->dislikes); ?>

                        <button class="dislike_btn">
                            <span id="icon"><i class="far fa-thumbs-down"></i></span>
                            <span id="count">0</span> Dislike
                        </button>
                        <!-- dislike logo -->
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\Project Kelas\binus_forum\resources\views/forum.blade.php ENDPATH**/ ?>