<?php $__env->startSection('title', 'Edit Course'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/editCourse.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="container-box">
        <div class="container-header">
            <h1 class="container-title">CREATE NEW COURSE</h1>
            <img class="container-icon" src="<?php echo e(URL::asset('images/plus.png')); ?>" alt="">
        </div>
        <hr class="container-line">

        <div class="container-content">
            <img class="form-icon" src="<?php echo e(URL::asset('images/course_icon.png')); ?>" alt="">

            <form class="edit-form" method="post" action="/create_course">
                <?php echo csrf_field(); ?>
                <label class="name-label" for="name">Course Name</label>
                <input class="textbox" type="text" name="name" id="name"
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="errorAlert"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input class="edit-button" type="submit" value="Create">
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BINUS UNIVERSITY\Semester 5\Web Programming\Project Dosen\binus_forum\resources\views/createCourse.blade.php ENDPATH**/ ?>