<?php $__env->startSection('title', 'Create Post'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/createpost.css')); ?>">

<?php $__env->startSection('content'); ?>
    <br><br><br><br>
    <?php if(Session::has('error')): ?>
    <div class="error">
      <h4>
        <?php echo e(Session::get('error')); ?>

      </h4>

        <?php
            Session::forget('error');
        ?>
    </div>
    <?php endif; ?>
    
    <?php if(Session::has('success')): ?>
    <div class="success">
    <h4>
        <?php echo e(Session::get('success')); ?>

    </h4>

        <?php
            Session::forget('success');
        ?>
    </div>
    <?php endif; ?>


    
    <?php if($errors->any()): ?>
    <div class="error">
        <p><strong>Opps Something went wrong</strong></p>
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    

    <div class="container">
        <form class="create-form"action="/send_post/<?php echo e($user->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <label class="course-label" for="">Courses</label>

            <input class="course-input input" list="list_course" type="text"
                name="courses_name" id="courses_name" placeholder="Choose..">

            <datalist id="list_course">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option  value="<?php echo e($course->name); ?>" > <?php echo e($course->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </datalist>

            <label class="title-label" for="title">Title</label>

            <input class="title-input input" type="text" name="title" id="title" required placeholder="Title Here...">

            <label class="description-label" for="description">Description</label>

            <textarea class="description-textarea input" name="description" id="description" placeholder="describe here..." required minlength="10"></textarea>

            <input class="submit-button" type="submit" value="Create Post">
        </form>

    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\Project Kelas\binus_forum\resources\views/createPost.blade.php ENDPATH**/ ?>