<?php $__env->startSection('title', 'Home'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/home.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="banner-section">
        <img class="forum-icon" src="<?php echo e(URL::asset('images/forum.png')); ?>" alt="">
        <h2 class="banner-title">BINUS FORUM | YOUR GATEWAY TO SUCCESS</h2>
    </div>

    
    <?php if(auth()->guard()->guest()): ?>
        <div class="feature-section">
            <h2 class="feature-title">Features</h2>
            <div class="feature-list">
                <div class="feature-box">
                    <img class="feature-icon" src="<?php echo e(URL::asset('images/post.png')); ?>" alt="">
                    <h3 class="feature-label">Post & Reply<br> Forum Discussions</h3>
                </div>
                <div class="feature-box">
                    <img class="feature-icon" src="<?php echo e(URL::asset('images/bookmark.png')); ?>" alt="">
                    <h3 class="feature-label">Bookmark Forum Posts</h3>
                </div>
                <div class="feature-box">
                    <img class="feature-icon" src="<?php echo e(URL::asset('images/unreadMessage.png')); ?>" alt="">
                    <h3 class="feature-label">View Unread Forums Posts</h3>
                </div>
            </div>
        </div>

        <div class="get-started-section">
            <div class="get-started-left-section">
                <img class="get-started-img" src="<?php echo e(URL::asset('images/getStarted.jpg')); ?>" alt="">
            </div>
            <div class="get-started-right-section">
                <h2 class="get-started-label">Come and join the greatest private university community</h2>
                <a href="/register" class="get-started-button">Get Started</a>
            </div>
        </div>
    <?php endif; ?>

    
    <?php if(auth()->guard()->check()): ?>
        
        <?php if($user->roles->name == "Student"): ?>
            <div class="unread-section">
                <h2 class="unread-title">Unread Post</h2>
                <hr class="title-line">

                <?php
                    $flag = 0
                ?>

                <?php $__currentLoopData = $allPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$readPosts->contains('posts_id', $post->id)): ?>
                        <a href="/post/<?php echo e($post->id); ?>" class="unread-post">

                            <div class="post-detail">
                                <h3 class="post-title"><?php echo e($post->title); ?></h3>
                                <h4 class="post-profile-name">Posted by: <?php echo e($post->users->name); ?></h4>
                            </div>

                            <div class="post-profile">
                                <p class="like-number"><?php echo e($post->likes); ?></p>
                                <img class="like-icon" src="<?php echo e(URL::asset('images/like_button.png')); ?>" alt="">
                                <p class="dislike-number"><?php echo e($post->dislikes); ?></p>
                                <img class="dislike-icon" src="<?php echo e(URL::asset('images/dislike_button.png')); ?>" alt="">
                            </div>
                        </a>
                        <?php
                            $flag += 1
                        ?>
                    <?php endif; ?>

                    <?php if($flag > 1): ?>
                        <?php break; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($flag == 0): ?>
                    <div class="empty-list">
                        <h3 class="empty-text">No Post Yet ..</h3>
                    </div>
                <?php endif; ?>

                <div class="more-section">
                    <a href="<?php echo e(URL('/unread_post')); ?>" class="more-button">more >></a>
                </div>
            </div>

            <div class="bookmark-section">
                <h2 class="bookmark-title">Bookmarked Post</h2>
                <hr class="title-line">

            <?php if($bookmarkPosts->isEmpty()): ?>
                <div class="empty-list">
                    <h3 class="empty-text">No Post Yet ..</h3>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $bookmarkPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/post/<?php echo e($post->posts_id); ?>" class="bookmark-post">
                        <div class="post-detail">
                            <h3 class="post-title"><?php echo e($post->posts->title); ?></h3>
                            <h4 class="post-profile-name">Posted by: <?php echo e($post->users->name); ?></h4>
                        </div>

                        <div class="post-profile">
                            <p class="like-number"><?php echo e($post->posts->likes); ?></p>
                            <img class="like-icon" src="<?php echo e(URL::asset('images/like_button.png')); ?>" alt="">
                            <p class="dislike-number"><?php echo e($post->posts->dislikes); ?></p>
                            <img class="dislike-icon" src="<?php echo e(URL::asset('images/dislike_button.png')); ?>" alt="">
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

                <div class="more-section">
                    <a href="<?php echo e(URL('/bookmark_post')); ?>" class="more-button">more >></a>
                </div>
            </div>

        
        <?php elseif($user->roles->name == "Lecturer"): ?>
            <div class="unread-section">
                <h2 class="unread-title">Unread Post</h2>
                <hr class="title-line">

                <?php
                    $flag = 0
                ?>

                <?php $__currentLoopData = $allPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$readPosts->contains('posts_id', $post->id)): ?>
                        <a href="/post/<?php echo e($post->id); ?>" class="unread-post">

                            <div class="post-detail">
                                <h3 class="post-title"><?php echo e($post->title); ?></h3>
                                <h4 class="post-profile-name">Posted by: <?php echo e($post->users->name); ?></h4>
                            </div>

                            <div class="post-profile">
                                <p class="like-number"><?php echo e($post->likes); ?></p>
                                <img class="like-icon" src="<?php echo e(URL::asset('images/like_button.png')); ?>" alt="">
                                <p class="dislike-number"><?php echo e($post->dislikes); ?></p>
                                <img class="dislike-icon" src="<?php echo e(URL::asset('images/dislike_button.png')); ?>" alt="">
                            </div>
                        </a>
                        <?php
                            $flag += 1
                        ?>
                    <?php endif; ?>

                    <?php if($flag > 1): ?>
                        <?php break; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($flag == 0): ?>
                    <div class="empty-list">
                        <h3 class="empty-text">No Post Yet ..</h3>
                    </div>
                <?php endif; ?>

                <div class="more-section">
                    <a href="<?php echo e(URL('/unread_post')); ?>" class="more-button">more >></a>
                </div>
            </div>

            <div class="bookmark-section">
                <h2 class="bookmark-title">Bookmarked Post</h2>
                <hr class="title-line">

            <?php if($bookmarkPosts->isEmpty()): ?>
                <div class="empty-list">
                    <h3 class="empty-text">No Post Yet ..</h3>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $bookmarkPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/post/<?php echo e($post->posts_id); ?>" class="bookmark-post">
                        <div class="post-detail">
                            <h3 class="post-title"><?php echo e($post->posts->title); ?></h3>
                            <h4 class="post-profile-name">Posted by: <?php echo e($post->users->name); ?></h4>
                        </div>

                        <div class="post-profile">
                            <p class="like-number"><?php echo e($post->posts->likes); ?></p>
                            <img class="like-icon" src="<?php echo e(URL::asset('images/like_button.png')); ?>" alt="">
                            <p class="dislike-number"><?php echo e($post->posts->dislikes); ?></p>
                            <img class="dislike-icon" src="<?php echo e(URL::asset('images/dislike_button.png')); ?>" alt="">
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

                <div class="more-section">
                    <a href="<?php echo e(URL('/bookmark_post')); ?>" class="more-button">more >></a>
                </div>
            </div>

        
        <?php elseif($user->roles->name == "Admin"): ?>
            <div class="unread-section">
                <h2 class="unread-title">Unread Post</h2>
                <hr class="title-line">

                <?php
                    $flag = 0
                ?>

                <?php $__currentLoopData = $allPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$readPosts->contains('posts_id', $post->id)): ?>
                        <a href="/post/<?php echo e($post->id); ?>" class="unread-post">

                            <div class="post-detail">
                                <h3 class="post-title"><?php echo e($post->title); ?></h3>
                                <h4 class="post-profile-name">Posted by: <?php echo e($post->users->name); ?></h4>
                            </div>

                            <div class="post-profile">
                                <p class="like-number"><?php echo e($post->likes); ?></p>
                                <img class="like-icon" src="<?php echo e(URL::asset('images/like_button.png')); ?>" alt="">
                                <p class="dislike-number"><?php echo e($post->dislikes); ?></p>
                                <img class="dislike-icon" src="<?php echo e(URL::asset('images/dislike_button.png')); ?>" alt="">
                            </div>
                        </a>
                        <?php
                            $flag += 1
                        ?>
                    <?php endif; ?>

                    <?php if($flag > 1): ?>
                        <?php break; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($flag == 0): ?>
                    <div class="empty-list">
                        <h3 class="empty-text">No Post Yet ..</h3>
                    </div>
                <?php endif; ?>

                <div class="more-section">
                    <a href="<?php echo e(URL('/unread_post')); ?>" class="more-button">more >></a>
                </div>
            </div>

            <div class="bookmark-section">
                <h2 class="bookmark-title">Bookmarked Post</h2>
                <hr class="title-line">

            <?php if($bookmarkPosts->isEmpty()): ?>
                <div class="empty-list">
                    <h3 class="empty-text">No Post Yet ..</h3>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $bookmarkPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/post/<?php echo e($post->posts_id); ?>" class="bookmark-post">
                        <div class="post-detail">
                            <h3 class="post-title"><?php echo e($post->posts->title); ?></h3>
                            <h4 class="post-profile-name">Posted by: <?php echo e($post->users->name); ?></h4>
                        </div>

                        <div class="post-profile">
                            <p class="like-number"><?php echo e($post->posts->likes); ?></p>
                            <img class="like-icon" src="<?php echo e(URL::asset('images/like_button.png')); ?>" alt="">
                            <p class="dislike-number"><?php echo e($post->posts->dislikes); ?></p>
                            <img class="dislike-icon" src="<?php echo e(URL::asset('images/dislike_button.png')); ?>" alt="">
                            <form class="delete-form" action="/delete_bookmark/<?php echo e($post->id); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button class="delete-button" type="submit"></button>
                            </form>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

                <div class="more-section">
                    <a href="<?php echo e(URL('/bookmark_post')); ?>" class="more-button">more >></a>
                </div>
            </div>

        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\goldi\OneDrive\Desktop\binus_forum\resources\views/home.blade.php ENDPATH**/ ?>