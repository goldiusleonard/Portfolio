<?php $__env->startSection('title', 'Unread Post'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/unread.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="unread-section">
        <h2 class="section-title">UNREAD POST</h2>
        <h3 class="section-subtitle">Never miss new post</h3>
    </div>

    <div class="search-section">
        <form method="get" action="">
            <input class="textbox" type="text" name="search" id="search" placeholder="Topic">
            <input class="search-button" type="submit" value="Search">
        </form>
    </div>

    <div class="list-section">
        <?php
            $flag = 0
        ?>

        <?php $__currentLoopData = $allPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!$readPosts->contains('posts_id', $post->id)): ?>
                <a href="/post/<?php echo e($post->id); ?>" class="unread-post">
                    <div class="post-detail">
                        <h3 class="post-title"><?php echo e($post->title); ?></h3>
                        <h4 class="post-profile-name">Posted by: <?php echo e($post->users->name); ?></h4>
                    </div>

                    <div class="post-profile">
                        <p class="like-number"><?php echo e($post->likes); ?></p>
                        <img class="like-icon" src="<?php echo e(URL::asset('images/like_button.png')); ?>" alt="">
                        <p class="dislike-number"><?php echo e($post->dislikes); ?></p>
                        <img class="dislike-icon" src="<?php echo e(URL::asset('images/dislike_button.png')); ?>" alt="">
                    </div>
                </a>
                <?php
                    $flag += 1
                ?>
            <?php endif; ?>

            <?php if($flag > 1): ?>
                <?php break; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($flag == 0): ?>
            <div class="empty-list">
                <h3 class="empty-text">No Post Yet ..</h3>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\Project Kelas\binus_forum (Mario)\resources\views/unreadPost.blade.php ENDPATH**/ ?>