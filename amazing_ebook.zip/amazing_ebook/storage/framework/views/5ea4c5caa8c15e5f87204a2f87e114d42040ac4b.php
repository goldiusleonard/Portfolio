<?php $__env->startSection('title', __('Sign Up')); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/signup.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="banner-container">
        <div class="banner">
            <h1 class="banner-text"><?php echo e(__('SIGN UP YOUR ACCOUNT')); ?></h1>
        </div>
    </div>

    <div class="signup-container">
        <form method="post" action="<?php echo e(route('signup_process')); ?>" enctype="multipart/form-data" class="signup-form">
            <?php echo csrf_field(); ?>
            <div class="signup-content">
                <div class="left-signup-content">
                    <div class="text-box">
                        <label class="text-label" for="<?php echo e(__('First_Name')); ?>"><?php echo e(__('First Name')); ?></label>
                        <input class="text-input" type="text" name="<?php echo e(__('First_Name')); ?>" id="<?php echo e(__('First_Name')); ?>"
                            <?php $__errorArgs = [__('First_Name')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                    </div>

                    <?php $__errorArgs = [__('First_Name')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="errorAlert"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="text-box">
                        <label class="text-label" for="<?php echo e(__('Last_Name')); ?>"><?php echo e(__('Last Name')); ?></label>
                        <input class="text-input" type="text" name="<?php echo e(__('Last_Name')); ?>" id="<?php echo e(__('Last_Name')); ?>"
                            <?php $__errorArgs = [__('Last_Name')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                    </div>

                    <?php $__errorArgs = [__('Last_Name')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="errorAlert"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="text-box">
                        <label class="text-label" for=""><?php echo e(__('Gender')); ?></label>
                        <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input class="radio-input" type="radio" name="<?php echo e(__('Gender_')); ?>" id="<?php echo e($gender->gender_desc); ?>" value="<?php echo e($gender->id); ?>"
                                <?php $__errorArgs = [__('Gender_')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                                <?php if($gender->gender_desc == "Male"): ?>
                                <label for="<?php echo e($gender->gender_desc); ?>"><?php echo e(__('Male')); ?></label>
                            <?php elseif($gender->gender_desc == "Female"): ?>
                                <label for="<?php echo e($gender->gender_desc); ?>"><?php echo e(__('Female')); ?></label>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <?php $__errorArgs = [__('Gender_')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="errorAlert"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="text-box">
                        <label class="text-label" for="<?php echo e(__('Password_')); ?>"><?php echo e(__('Password')); ?></label>
                        <input class="text-input" type="password" name="<?php echo e(__('Password_')); ?>" id="<?php echo e(__('Password_')); ?>"
                            <?php $__errorArgs = [__('Password_')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                    </div>

                    <?php $__errorArgs = [__('Password_')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="errorAlert"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="right-signup-content">
                    <div class="text-box">
                        <label class="text-label" for="<?php echo e(__('Middle_Name')); ?>"><?php echo e(__('Middle Name')); ?></label>
                        <input class="text-input" type="text" name="<?php echo e(__('Middle_Name')); ?>" id="<?php echo e(__('Middle_Name')); ?>"
                            <?php $__errorArgs = [__('Middle_Name')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                    </div>

                    <?php $__errorArgs = [__('Middle_Name')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="errorAlert"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="text-box">
                        <label class="text-label" for="<?php echo e(__('Email_Address')); ?>"><?php echo e(__('Email Address')); ?></label>
                        <input class="text-input" type="email" name="<?php echo e(__('Email_Address')); ?>" id="<?php echo e(__('Email_Address')); ?>"
                            <?php $__errorArgs = [__('Email_Address')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                    </div>

                    <?php $__errorArgs = [__('Email_Address')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="errorAlert"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="text-box">
                        <label class="text-label" for="<?php echo e(__('Role_')); ?>"><?php echo e(__('Role')); ?></label>
                        <select  class="text-input" name="<?php echo e(__('Role_')); ?>" id="<?php echo e(__('Role_')); ?>"
                            <?php $__errorArgs = [__('Role_')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>"><?php echo e($role->role_desc); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <?php $__errorArgs = [__('Role_')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="errorAlert"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="text-box">
                        <label class="text-label" for="<?php echo e(__('Display_Picture')); ?>"><?php echo e(__('Display Picture')); ?></label>
                        <input type="file" name="<?php echo e(__('Display_Picture')); ?>" id="<?php echo e(__('Display_Picture')); ?>"
                            <?php $__errorArgs = [__('Display_Picture')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                    </div>

                    <?php $__errorArgs = [__('Display_Picture')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="errorAlert"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <input class="submit-btn" type="submit" value="<?php echo e(__('Sign Up')); ?>">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\UAS\amazing_ebook\resources\views/signup.blade.php ENDPATH**/ ?>