<?php $__env->startSection('title', __('Log In')); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/login.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="banner-container">
        <div class="banner">
            <h1 class="banner-text"><?php echo e(__('LOG IN TO YOUR ACCOUNT')); ?></h1>
        </div>
    </div>

    <div class="login-container">
        <form class="login-form" method="post" enctype="multipart/form-data" action="<?php echo e(route('login_process')); ?>">
            <?php echo csrf_field(); ?>
            <div class="text-box">
                <label class="text-label" for="<?php echo e(__('Email_Address')); ?>"><?php echo e(__('Email Address')); ?></label>
                <input class="text-input" type="email" name="<?php echo e(__('Email_Address')); ?>" id="<?php echo e(__('Email_Address')); ?>"
                    <?php $__errorArgs = [__('Email_Address')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
            </div>

            <?php $__errorArgs = [__('Email_Address')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="errorAlert"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="text-box">
                <label class="text-label" for="<?php echo e(__('Password_')); ?>"><?php echo e(__('Password')); ?></label>
                <input class="text-input" type="password" name="<?php echo e(__('Password_')); ?>" id="<?php echo e(__('Password_')); ?>"
                    <?php $__errorArgs = [__('Password_')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
            </div>

            <?php $__errorArgs = [__('Password_')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="errorAlert"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php if($errors->any()): ?>
                <div class="text-box">
                    <label class="text-label" for=""> </label>
                    <div class="errorAlert">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($error == __('Invalid Email or Password')): ?>
                                <p><?php echo e($error); ?></p>
                            <?php elseif($error == __('Your account is deactivated. Please contact the admin.')): ?>
                                <p><?php echo e($error); ?></p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="text-box">
                <label class="text-label" for=""> </label>
                <input type="checkbox" id="<?php echo e(__('Remember Me')); ?>" name="<?php echo e(__('Remember Me')); ?>" class="checkbox">
                <label for="remember"><?php echo e(__('Remember Me')); ?></label>
            </div>

            <div class="text-box">
                <label class="text-label" for=""> </label>
                <input class="submit-btn" type="submit" value="<?php echo e(__('Log In')); ?>">
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\UAS\amazing_ebook\resources\views/login.blade.php ENDPATH**/ ?>