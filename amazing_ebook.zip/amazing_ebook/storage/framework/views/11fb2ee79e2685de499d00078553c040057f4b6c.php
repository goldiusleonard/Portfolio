<?php $__env->startSection('title', __('Home')); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/home.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="banner-container">
        <div class="banner">
            <h1 class="banner-text"><?php echo e(__('Find & Rent Your E-Book Here!')); ?></h1>
        </div>
    </div>
    <?php if(auth()->guard()->guest()): ?>
        <div class="get-started-section">
            <img class="get-started-icon" src="<?php echo e(URL::asset('images/book_picture.png')); ?>" alt="">

            <div class="right-get-started">
                <h4 class=""></h4>
                <h2 class="right-get-started-text"><?php echo e(__('no account')); ?></h2>
                <a class="get-started-btn" href="<?php echo e(route('signup')); ?>">
                    <?php echo e(__('Get Started')); ?>

                </a>
            </div>
        </div>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
        <div class="sub-menu">
            <div class="sub-menu-bar">
                <?php if($user->role->role_desc == 'User'): ?>
                    <a class="menu-choice selected" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                    <a class="menu-choice" href="<?php echo e(route('cart')); ?>"><?php echo e(__('Cart')); ?></a>
                    <a class="menu-choice" href="<?php echo e(route('profile')); ?>"><?php echo e(__('Profile')); ?></a>
                <?php elseif($user->role->role_desc == 'Admin'): ?>
                    <a class="menu-choice selected" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                    <a class="menu-choice" href="<?php echo e(route('cart')); ?>"><?php echo e(__('Cart')); ?></a>
                    <a class="menu-choice" href="<?php echo e(route('profile')); ?>"><?php echo e(__('Profile')); ?></a>
                    <a class="menu-choice" href="<?php echo e(route('account_maintenance')); ?>"><?php echo e(__('Account Maintenance')); ?></a>
                <?php endif; ?>
            </div>
        </div>

        <div class="ebook-section">
            <h2 class="ebook-section-title"><?php echo e(__('E-Book Collections')); ?></h2>

            <?php if($ebooks->isEmpty()): ?>
                <div class="ebook-list">
                    <img class="ebook-list-empty-icon" src="<?php echo e(URL::asset('images/empty_icon.png')); ?>" alt="">
                    <h3 class="ebook-list-empty"><?php echo e(__('ebook list empty')); ?></h3>
                </div>
            <?php else: ?>
                <div class="ebook-list">
                    <?php $__currentLoopData = $ebooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ebook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="ebook-item" href="/ebook_detail/<?php echo e($ebook->id); ?>">
                            <h3 class="ebook-title"><?php echo e($ebook->title); ?></h3>
                            <h5 class="ebook-author"><?php echo e(__('Author')); ?>: <?php echo e($ebook->author); ?></h5>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <?php if($ebooks->lastPage() > 1): ?>
                <div class="pagination">
                    <?php if($ebooks->currentPage() > 1): ?>
                        <a class="pagination-btn" href="<?php echo e($ebooks->url($ebooks->currentPage() - 1)); ?>"><?php echo e(__('Previous')); ?></a>
                    <?php endif; ?>

                    <p class="pagination-page"><?php echo e($ebooks->firstItem()); ?> - <?php echo e($ebooks->lastItem()); ?> <?php echo e(__('of')); ?> <?php echo e($ebooks->total()); ?></p>

                    <?php if($ebooks->currentPage() != $ebooks->lastPage()): ?>
                        <a class="pagination-btn" href="<?php echo e($ebooks->url($ebooks->currentPage() + 1)); ?>"><?php echo e(__('Next')); ?></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\UAS\amazing_ebook\resources\views/home.blade.php ENDPATH**/ ?>