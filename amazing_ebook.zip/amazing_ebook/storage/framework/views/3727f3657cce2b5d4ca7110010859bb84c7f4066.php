<?php $__env->startSection('title', 'Login'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/login.css')); ?>">

<?php $__env->startSection('content'); ?>
        <form method="POST" action='/login' enctype="multipart/form-data" class="form">
            <?php echo csrf_field(); ?>
            <div class="form_row">
                <div class="label_column">
                    <label for="email">E-Mail Address</label>
                </div>
                <div class="input_column flex_column">
                    <input type="email" id="email" name="email" placeholder="" class="textbox" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="errorAlert"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form_row">
                <div class="label_column">
                    <label for="password">Password</label>
                </div>
                <div class="input_column flex_column">
                    <input type="password" id="password" name="password" placeholder="" class="textbox" <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="errorAlert"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form_row">
                <div class="label_column">
                </div>
                <div class="input_column">
                    <input type="checkbox" id="remember" name="remember" class="checkbox">
                    <label for="remember">Remember Me</label>
                </div>
            </div>
            <div class="form_row">
                <div class="label_column">
                    <label for=""></label>
                </div>
                <div class="input_column">
                    <input type="submit" value="Login" class="submit_button">
                </div>
            </div>
            <div class="form_row">
                <div class="label_column">
                    <label for=""></label>
                </div>
                <div class="input_column">
                    <div class="errorAlert">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($error == "Invalid Email or Password"): ?>
                                <p><?php echo e($error); ?></p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\Project Kelas\binus_forum (Mario)\resources\views/login.blade.php ENDPATH**/ ?>