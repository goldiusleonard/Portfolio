<?php $__env->startSection('title', 'category'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/course.css')); ?>">

<?php $__env->startSection('content'); ?>
    
    <div class="banner-section">
        <img class="forum-icon" src="<?php echo e(URL::asset('images/forum.png')); ?>" alt="">
        <h2 class="banner-title"><?php echo e($selected_course->name); ?></h2>
    </div>

    <div class="search-section">
        <form method="get" action="" role="search" class="search-form">
            <input class="search-textbox" type="text" name="search" id="search" placeholder="Forum Topic" <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
            <input type="submit" value="search" class="search-submit" >
        </form>
        <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="post-section">
        <?php if($posts->isEmpty()): ?>
            <div class="empty-list">
                <h3 class="empty-text">No Post Yet ..</h3>
            </div>
        <?php else: ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/post/<?php echo e($post->id); ?>" class="unread-post">
                    <div class="post-detail">
                        <h3 class="post-title"><?php echo e($post->title); ?></h3>
                        <h4 class="post-profile-name">Posted by: <?php echo e($post->users->name); ?></h4>
                    </div>

                    <div class="post-profile">
                        <p class="like-number"><?php echo e($post->likes); ?></p>
                        <img class="like-icon" src="<?php echo e(URL::asset('images/like_button.png')); ?>" alt="">
                        <p class="dislike-number"><?php echo e($post->dislikes); ?></p>
                        <img class="dislike-icon" src="<?php echo e(URL::asset('images/dislike_button.png')); ?>" alt="">
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FileCko\Kuliah\binus_forum\resources\views/course.blade.php ENDPATH**/ ?>