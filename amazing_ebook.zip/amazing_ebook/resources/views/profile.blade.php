@extends('master.layout')

@section('title', __('Profile'))
<link rel="stylesheet" href="{{ URL::asset('css/profile.css') }}">

@section('content')
    <div class="sub-menu">
        <div class="sub-menu-bar">
            @if ($user->role->role_desc == 'User')
                <a class="menu-choice" href="{{ route('home') }}">{{ __('Home') }}</a>
                <a class="menu-choice" href="{{ route('cart') }}">{{ __('Cart') }}</a>
                <a class="menu-choice selected" href="{{ route('profile') }}">{{ __('Profile') }}</a>
            @elseif ($user->role->role_desc == 'Admin')
                <a class="menu-choice" href="{{ route('home') }}">{{ __('Home') }}</a>
                <a class="menu-choice" href="{{ route('cart') }}">{{ __('Cart') }}</a>
                <a class="menu-choice selected" href="{{ route('profile') }}">{{ __('Profile') }}</a>
                <a class="menu-choice" href="{{ route('account_maintenance') }}">{{ __('Account Maintenance') }}</a>
            @endif
        </div>
    </div>

    <div class="container">
        <div class="left-container">
            <img class="profile-picture" src="{{ asset('storage/' . $user->display_picture_link) }}" alt="">
        </div>

        <div class="right-container">
            <form class="profile-form" method="post" action="{{ route('update_profile') }}" enctype="multipart/form-data">
                @csrf
                <div class="profile-content">
                    <div class="left-profile-content">
                        <div class="text-box">
                            <label class="text-label" for="{{ __('First_Name') }}">{{ __('First Name') }}</label>
                            <input class="text-input" type="text" name="{{ __('First_Name') }}" id="{{ __('First_Name') }}"
                                value="{{ $user->first_name }}"
                                @error(__('First_Name')) is-invalid @enderror>
                        </div>

                        @error(__('First_Name'))
                            <p class="errorAlert">{{$message}}</p>
                        @enderror

                        <div class="text-box">
                            <label class="text-label" for="{{ __('Last_Name') }}">{{ __('Last Name') }}</label>
                            <input class="text-input" type="text" name="{{ __('Last_Name') }}" id="{{ __('Last_Name') }}"
                                value="{{ $user->last_name }}"
                                @error(__('Last_Name')) is-invalid @enderror>
                        </div>

                        @error(__('Last_Name'))
                            <p class="errorAlert">{{$message}}</p>
                        @enderror

                        <div class="text-box">
                            <label class="text-label" for="">{{ __('Gender') }}</label>
                            @foreach ($genders as $gender)
                                @if ($gender->id == $user->gender_id)
                                    <input class="radio-input" checked type="radio" name="{{ __('Gender_') }}" id="{{ $gender->gender_desc }}" value="{{ $gender->id }}"
                                        @error(__('Gender_')) is-invalid @enderror>
                                    @if ($gender->gender_desc == "Male")
                                        <label for="{{ $gender->gender_desc }}">{{__('Male')}}</label>
                                    @elseif($gender->gender_desc == "Female")
                                        <label for="{{ $gender->gender_desc }}">{{__('Female')}}</label>
                                    @endif
                                @else
                                    <input class="radio-input" type="radio" name="{{ __('Gender_') }}" id="{{ $gender->gender_desc }}" value="{{ $gender->id }}"
                                        @error(__('Gender_')) is-invalid @enderror>
                                    @if ($gender->gender_desc == "Male")
                                        <label for="{{ $gender->gender_desc }}">{{__('Male')}}</label>
                                    @elseif($gender->gender_desc == "Female")
                                        <label for="{{ $gender->gender_desc }}">{{__('Female')}}</label>
                                    @endif
                                @endif
                            @endforeach
                        </div>

                        @error(__('Gender_'))
                            <p class="errorAlert">{{$message}}</p>
                        @enderror

                        <div class="text-box">
                            <label class="text-label" for="{{__('Password_')}}">{{__('Password')}}</label>
                            <input class="text-input" type="password" name="{{__('Password_')}}" id="{{__('Password_')}}"
                                @error(__('Password_')) is-invalid @enderror>
                        </div>

                        @error(__('Password_'))
                            <p class="errorAlert">{{$message}}</p>
                        @enderror
                    </div>

                    <div class="right-profile-content">
                        <div class="text-box">
                            <label class="text-label" for="{{__('Middle_Name')}}">{{__('Middle Name')}}</label>
                            <input class="text-input" type="text" name="{{__('Middle_Name')}}" id="{{__('Middle_Name')}}"
                                value="{{ $user->middle_name }}"
                                @error(__('Middle_Name')) is-invalid @enderror>
                        </div>

                        @error(__('Middle_Name'))
                            <p class="errorAlert">{{$message}}</p>
                        @enderror

                        <div class="text-box">
                            <label class="text-label" for="{{__('Email_Address')}}">{{__('Email Address')}}</label>
                            <input class="text-input" type="email" name="{{__('Email_Address')}}" id="{{__('Email_Address')}}"
                                value="{{ $user->email }}"
                                @error(__('Email_Address')) is-invalid @enderror>
                        </div>

                        @error(__('Email_Address'))
                            <p class="errorAlert">{{$message}}</p>
                        @enderror

                        <div class="text-box">
                            <label class="text-label" for="{{__('Role_')}}">{{__('Role')}}</label>
                            <select  class="text-input" name="{{__('Role_')}}" id="{{__('Role_')}}"
                                @error(__('Role_')) is-invalid @enderror>
                                @foreach ($roles as $role)
                                    @if ($role->id == $user->role_id)
                                        <option selected value="{{ $role->id }}">{{ $role->role_desc }}</option>
                                    @endif
                                @endforeach
                            </select>
                        </div>

                        @error(__('Role_'))
                            <p class="errorAlert">{{$message}}</p>
                        @enderror

                        <div class="text-box">
                            <label class="text-label" for="{{__('Display_Picture')}}">{{__('Display Picture')}}</label>
                            <input type="file" name="{{__('Display_Picture')}}" id="{{__('Display_Picture')}}"
                                @error(__('Display_Picture')) is-invalid @enderror>
                        </div>

                        @error(__('Display_Picture'))
                            <p class="errorAlert">{{$message}}</p>
                        @enderror
                    </div>
                </div>

                <input class="save-btn" type="submit" value="{{__('Save')}}">
            </form>
        </div>
    </div>
@endsection
