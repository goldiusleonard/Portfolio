<?php
return [
    'en' => 'English',
    'id' => 'Indonesian'
];
