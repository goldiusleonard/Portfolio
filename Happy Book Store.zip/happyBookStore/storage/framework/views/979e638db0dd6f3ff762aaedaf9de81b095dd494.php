<?php $__env->startSection('title', 'Contact'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/contact.css')); ?>">

<?php $__env->startSection('content'); ?>
<div class="promo">
    <h1 class="promoLabel">CONTACT</h1>
    <hr class="promoLine">
</div>

<div class="bookList">
    <div class="bookListSection">
        <div class="bookTitleSection">
            <h2 class="bookListTitle">OUR DETAIL</h2>
        </div>

        <div class="bookTable">
            <div class="storeLocationSection">
                <div class="titleSection">
                    <img src="<?php echo e(URL::asset('images/location.png')); ?>" alt="" class="storeLocationIcon">
                    <h2 class="storeLocationTitle">Store Location</h2>
                </div>

                <div class="contentSection">
                    <h3 class="address">
                        Jalan Pembangunan Baru Raya,<br>
                        Kompleks Pertokoan Emerald Blok III/12<br>
                        Bintaro, Tangerang Selatan<br>
                        Indonesia
                    </h3>
                </div>
            </div>

            <div class="openDailySection">
                <div class="titleSection">
                    <img src="<?php echo e(URL::asset('images/calendar.png')); ?>" alt="" class="storeLocationIcon">
                    <h2 class="openDailyTitle">Open Daily</h2>
                </div>

                <div class="contentSection">
                    <h3 class="address">
                        08.00 - 20.00
                    </h3>
                </div>
            </div>

            <div class="contactSection">
                <div class="titleSection">
                    <img src="<?php echo e(URL::asset('images/telephone.png')); ?>" alt="" class="storeLocationIcon">
                    <h2 class="contactTitle">Contact</h2>
                </div>

                <div class="contentSection">
                    <h3 class="address">
                        Phone   : 021-08899776655<br>
                        Email   : happybookstore@happy.com
                    </h3>
                </div>
            </div>
        </div>

    </div>

    <div class="categoryListSection">
        <div class="categoryTitleSection">
            <h2 class="categoryTitle">CATEGORY</h2>
        </div>

        <div class="categoryTable">
            <div class="scrollableCategory">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/category/<?php echo e($category->id); ?>" class="tableContentCategory">
                        <h3 class="categoryText"><?php echo e($category->category); ?></h3>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\UTS\happyBookStore\resources\views/contact.blade.php ENDPATH**/ ?>