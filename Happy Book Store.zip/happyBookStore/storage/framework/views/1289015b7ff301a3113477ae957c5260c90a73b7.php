<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent("title"); ?> | Happy Book Store</title>
    <link rel="shortcut icon" href="<?php echo e(URL::asset('images/logo.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/layout.css')); ?>">
</head>
<body>
    <nav>
        <div class="logoSection">
            <a href="/" class="logo"><img src="<?php echo e(URL::asset('images/logo.png')); ?>" alt="" class="logo"></a>
            <h2 class="title">Happy Book Store</h2>
        </div>

        <div class="menuSection">
            <a href="/" class="menuBtn">
                <h2>Home</h2>
            </a>
            <div class="dropDown">
                <div class="dropDownBtn">
                    <h2>Category</h2>
                    <img src="<?php echo e(URL::asset('images/dropDownArrow.png')); ?>" alt="" class="dropDownArrow">
                </div>
                <div class="dropDownContent">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="/category/<?php echo e($category->id); ?>" class="dropDownItem">
                            <?php echo e($category->category); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <a href="/contact" class="menuBtn">
                <h2>Contact</h2>
            </a>
        </div>
    </nav>

    <div class="content">
        <?php echo $__env->yieldContent("content"); ?>
    </div>

    <footer>
        <h3 class="copyright">© 2021 Copyright Happy Book Store</h3>
    </footer>

</body>
</html>
<?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\UTS\happyBookStore\resources\views/master/layout.blade.php ENDPATH**/ ?>