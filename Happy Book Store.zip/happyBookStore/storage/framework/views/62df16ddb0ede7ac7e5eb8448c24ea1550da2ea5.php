<?php $__env->startSection('title', $book->title); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/detail.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="promo <?php echo e($book->categories->category); ?>">
        <h1 class="promoLabel"><?php echo e(Str::upper($book->title)); ?></h1>
        <hr class="promoLine">
    </div>

    <div class="bookList">
        <div class="bookListSection">
            <div class="bookTitleSection">
                <h2 class="bookListTitle">BOOK DETAIL</h2>
            </div>

            <div class="bookTable">
                <h2 class="detail titleDetail"><?php echo e($book->title); ?></h2>
                <h2 class="detail yearDetail"><?php echo e($book->details->year); ?></h2>
                <br>
                <h2 class="detail authorDetail">By : <?php echo e($book->details->author); ?> (author)</h2>
                <h2 class="detail publisherDetail">Published by : <?php echo e($book->details->publisher); ?></h2>
                <br>
                <br>
                <h2 class="detail descriptionDetail">Description:</h2>
                <h2 class="description"><?php echo e($book->details->description); ?></h2>
            </div>

        </div>

        <div class="categoryListSection">
            <div class="categoryTitleSection">
                <h2 class="categoryTitle">CATEGORY</h2>
            </div>

            <div class="categoryTable">
                <div class="scrollableCategory">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="/category/<?php echo e($category->id); ?>" class="tableContentCategory">
                            <h3 class="categoryText"><?php echo e($category->category); ?></h3>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\UTS\happyBookStore\resources\views/detail.blade.php ENDPATH**/ ?>