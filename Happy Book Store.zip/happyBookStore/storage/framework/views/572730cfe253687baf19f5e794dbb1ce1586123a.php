<?php $__env->startSection('title', 'Home'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('css/home.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="promo">
        <h1 class="promoLabel">WELCOME BOOKSTERS!</h1>
        <hr class="promoLine">
        <h2 class="promoTag">Your One-Stop Book Store</h2>
    </div>

    <div class="bookList">
        <div class="bookListSection">
            <div class="bookTitleSection">
                <h2 class="bookListTitle">BOOK LIST</h2>
            </div>

            <div class="bookTable">
                <div class="tableTitle">
                    <h3 class="titleColumn titleText">Title</h3>
                    <h3 class="authorColumn titleText">Author</h3>
                </div>

                <div class="scrollableBook">
                    <?php
                        $index = 0
                    ?>
                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($index % 2 == 0): ?>
                            <a href="/detail/<?php echo e($book->id); ?>" class="tableContentBooksEven">
                                <h3 class="titleColumn contentTextEven"><?php echo e($book->title); ?></h3>
                                <h3 class="authorColumn contentTextEven"><?php echo e($book->details->author); ?></h3>
                            </a>
                        <?php else: ?>
                            <a href="/detail/<?php echo e($book->id); ?>" class="tableContentBooksOdd">
                                <h3 class="titleColumn contentTextOdd"><?php echo e($book->title); ?></h3>
                                <h3 class="authorColumn contentTextOdd"><?php echo e($book->details->author); ?></h3>
                            </a>
                        <?php endif; ?>
                        <?php
                            $index += 1
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>

        <div class="categoryListSection">
            <div class="categoryTitleSection">
                <h2 class="categoryTitle">CATEGORY</h2>
            </div>

            <div class="categoryTable">
                <div class="scrollableCategory">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="/category/<?php echo e($category->id); ?>" class="tableContentCategory">
                            <h3 class="categoryText"><?php echo e($category->category); ?></h3>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Kuliah\Semester 5\COMP6681001 - Web Programming\UTS\happyBookStore\resources\views/home.blade.php ENDPATH**/ ?>